import Ember from 'ember';

var AddRoute = Ember.Route.extend({



});

export default AddRoute;