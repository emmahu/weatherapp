import Ember from 'ember';

var EditRoute = Ember.Route.extend({



});

export default EditRoute;