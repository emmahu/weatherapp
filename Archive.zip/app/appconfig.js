import Ember from 'ember';

var appconfig = Ember.Object.create({
   useUSUnits: false,
});

export default appconfig;