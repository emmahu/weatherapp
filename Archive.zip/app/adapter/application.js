// import DS from'ember-data';



// exportdefault DS.LSAdapter.extend({

//   namespace: 'api/v1'

// });

